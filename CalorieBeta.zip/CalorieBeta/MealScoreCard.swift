import SwiftUI

struct MealScoreCard: View {
    let score: MealScore
    @State private var showDetail = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                VStack(alignment: .leading) {
                    Text("Yesterday's Report Card")
                        .appFont(size: 17, weight: .semibold)
                    Text(score.summary)
                        .appFont(size: 15)
                        .foregroundColor(Color(UIColor.secondaryLabel))
                }
                Spacer()
                VStack {
                    Text(score.grade)
                        .appFont(size: 48, weight: .bold)
                        .foregroundColor(score.color)
                    Text("\(score.overallScore)/100")
                        .appFont(size: 12, weight: .semibold)
                        .foregroundColor(Color(UIColor.secondaryLabel))
                }
            }

            Divider()
            
            VStack(spacing: 10) {
                ScoreRow(title: "Calorie Control", score: score.calorieScore)
                ScoreRow(title: "Macro Balance", score: score.macroScore)
                ScoreRow(title: "Food Quality", score: score.qualityScore)
                ScoreRow(title: "Timing & Balance", score: score.balanceScore)
            }
        }
        .asCard()
        .contentShape(Rectangle())
        .onTapGesture {
            showDetail = true
        }
        .sheet(isPresented: $showDetail) {
            NavigationView {
                MealScoreDetailView(score: score)
            }
        }
    }
}

private struct ScoreRow: View {
    let title: String
    let score: Int
    
    private var scoreColor: Color {
        switch score {
        case 90...: return .accentPositive
        case 70..<90: return .yellow
        case 50..<70: return .orange
        default: return .red
        }
    }
    
    var body: some View {
        HStack {
            Text(title)
                .appFont(size: 14)
            Spacer()
            ProgressView(value: Double(score) / 100.0)
                .progressViewStyle(LinearProgressViewStyle(tint: scoreColor))
                .frame(width: 80)
            
            Text("\(score)%")
                .appFont(size: 14, weight: .bold)
                .foregroundColor(scoreColor)
                .frame(width: 40, alignment: .trailing)
        }
    }
}
