import SwiftUI

struct IngredientRowView: View {
    @Binding var ingredient: RecipeIngredient
    var onMatchFound: (FoodItem) -> Void
    
    @State private var foodItem: FoodItem?
    private let foodAPIService = FatSecretFoodAPIService()
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(ingredient.foodName.capitalized)
                    .appFont(size: 16, weight: .semibold)
                
                if let foodItem = foodItem {
                    Text("\(foodItem.calories, specifier: "%.0f") kcal, P: \(foodItem.protein, specifier: "%.0f")g, C: \(foodItem.carbs, specifier: "%.0f")g, F: \(foodItem.fats, specifier: "%.0f")g")
                        .appFont(size: 12)
                        .foregroundColor(.secondary)
                } else {
                    Text("Matching ingredient...")
                        .appFont(size: 12)
                        .foregroundColor(.orange)
                }
            }
            
            Spacer()
            
            if foodItem != nil {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(.green)
            } else {
                Image(systemName: "magnifyingglass.circle")
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 4)
        .onAppear(perform: findMatchingFood)
    }
    
    private func findMatchingFood() {
        guard ingredient.foodId == nil else {
            self.foodItem = FoodItem(id: ingredient.foodId!, name: ingredient.foodName, calories: ingredient.calories, protein: ingredient.protein, carbs: ingredient.carbs, fats: ingredient.fats, servingSize: ingredient.selectedServingDescription ?? "", servingWeight: ingredient.selectedServingWeightGrams ?? 0)
            return
        }
        
        foodAPIService.fetchFoodByQuery(query: ingredient.foodName) { result in
            DispatchQueue.main.async {
                if case .success(let items) = result, let bestMatch = items.first {
                    self.foodItem = bestMatch
                    self.onMatchFound(bestMatch)
                }
            }
        }
    }
}
