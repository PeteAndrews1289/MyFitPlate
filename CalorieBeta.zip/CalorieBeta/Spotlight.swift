import SwiftUI

struct Spotlight: Identifiable {
    var id: String
    var title: String
    var text: String
}
