import SwiftUI
import FirebaseAuth

struct FoodSearchView: View {
    @Binding var dailyLog: DailyLog?
    var onFoodItemLogged: (FoodItem) -> Void
    var initialSearchQuery: String?
    var searchContext: String

    @State private var searchQuery: String = ""
    @State private var searchResults: [FoodItem] = []
    @State private var recentFoodItems: [FoodItem] = []
    @State private var myFoodItems: [FoodItem] = []
    @State private var selectedFoodItemForDetail: FoodItem? = nil
    @State private var isLoading = false
    @State private var showingAddFoodManually = false
    @State private var errorState: (isShowing: Bool, message: String) = (false, "")
    @State private var showingBarcodeScanner = false
    @State private var debounceTimer: Timer?
    
    @Environment(\.dismiss) private var dismiss
    private let foodAPIService = FatSecretFoodAPIService()
    @EnvironmentObject var dailyLogService: DailyLogService
    
    enum SearchCategory: String, CaseIterable {
        case search = "Search"
        case recents = "Recents"
        case myFoods = "My Foods"
    }
    @State private var selectedCategory: SearchCategory = .search

    var body: some View {
        NavigationView {
            VStack {
                Picker("Category", selection: $selectedCategory) {
                    ForEach(SearchCategory.allCases, id: \.self) { category in
                        Text(category.rawValue)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)

                switch selectedCategory {
                case .search:
                    searchSection
                case .recents:
                    recentsSection
                case .myFoods:
                    myFoodsSection
                }
            }
            .background(Color.backgroundPrimary.edgesIgnoringSafeArea(.all))
            .navigationTitle(searchContext == "recipe" ? "Add Ingredient" : "Add Food")
            .navigationBarItems(leading: Button("Cancel") { dismiss() }.foregroundColor(.brandPrimary))
            .sheet(isPresented: $showingAddFoodManually) {
                AddFoodView { newFood in
                    onFoodItemLogged(newFood)
                    dismiss()
                }
            }
            .sheet(item: $selectedFoodItemForDetail) { foodItem in
                NavigationView {
                    FoodDetailView(
                        initialFoodItem: foodItem,
                        dailyLog: $dailyLog,
                        date: dailyLogService.activelyViewedDate,
                        source: "search_result",
                        onLogUpdated: { onFoodItemLogged(foodItem) }
                    )
                }
            }
            .sheet(isPresented: $showingBarcodeScanner) {
                BarcodeScannerView { barcode in
                    self.showingBarcodeScanner = false
                    searchByBarcode(barcode: barcode)
                }
            }
            .alert("Search Error", isPresented: $errorState.isShowing) {
                Button("OK") { }
            } message: {
                Text(errorState.message)
            }
            .onAppear(perform: setupView)
        }
    }

    private var searchSection: some View {
        VStack {
            HStack {
                TextField("Search for food...", text: $searchQuery)
                    .textFieldStyle(AppTextFieldStyle(iconName: "magnifyingglass"))
                    .keyboardType(.default)
                    .onChange(of: searchQuery) {
                        handleSearchQueryChange(searchQuery)
                    }
                Button(action: { showingBarcodeScanner = true }) {
                    Image(systemName: "barcode.viewfinder")
                        .font(.title2)
                        .foregroundColor(.brandPrimary)
                }
            }
            .padding()

            if isLoading {
                ProgressView()
                Spacer()
            } else if searchResults.isEmpty && !searchQuery.isEmpty {
                VStack(spacing: 15) {
                    Text("No results found for '\(searchQuery)'")
                        .foregroundColor(Color(UIColor.secondaryLabel))
                    Button("Add Food Manually") {
                        showingAddFoodManually = true
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.horizontal, 40)
                }
                .padding(.top, 50)
                Spacer()
            } else {
                List(searchResults) { foodItem in
                    foodRow(for: foodItem)
                }
                .listStyle(InsetGroupedListStyle())
            }
        }
    }
    
    private var recentsSection: some View {
        VStack {
            if isLoading {
                ProgressView()
            } else if recentFoodItems.isEmpty {
                Text("No recent foods logged.")
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .padding(.top, 50)
                Spacer()
            } else {
                List(recentFoodItems) { foodItem in
                    foodRow(for: foodItem)
                }
                .listStyle(InsetGroupedListStyle())
            }
        }
    }
    
    private var myFoodsSection: some View {
        VStack {
            if isLoading {
                ProgressView()
            } else if myFoodItems.isEmpty {
                Text("You haven't saved any custom foods yet.")
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .padding(.top, 50)
                Text("Tap the star icon on a food's detail page to save it here.")
                    .appFont(size: 12)
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                Spacer()
            } else {
                List(myFoodItems) { foodItem in
                    foodRow(for: foodItem)
                }
                .listStyle(InsetGroupedListStyle())
            }
        }
    }

    private func handleFoodSelection(_ foodItem: FoodItem) {
        isLoading = true
        foodAPIService.fetchFoodDetails(foodId: foodItem.id) { result in
            isLoading = false
            switch result {
            case .success(let (detailedFoodItem, _)):
                onFoodItemLogged(detailedFoodItem)
                dismiss()
            case .failure(let error):
                errorState = (true, "Could not fetch details for this food. \(error.localizedDescription)")
            }
        }
    }

    private func foodRow(for foodItem: FoodItem) -> some View {
        Button(action: {
            if searchContext == "recipe" {
                handleFoodSelection(foodItem)
            } else {
                self.selectedFoodItemForDetail = foodItem
            }
        }) {
            HStack {
                VStack(alignment: .leading) {
                    Text(foodItem.name)
                        .appFont(size: 15, weight: .medium)
                    Text(foodItem.servingSize)
                        .appFont(size: 12)
                        .foregroundColor(Color(UIColor.secondaryLabel))
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.secondary)
            }
            .foregroundColor(.textPrimary)
        }
    }
    
    private func setupView() {
        if let query = initialSearchQuery, !query.isEmpty {
            self.searchQuery = query
            searchByQuery()
        }
        fetchRecentFoods()
        fetchMyFoods()
    }
    
    private func handleSearchQueryChange(_ newValue: String) {
        debounceTimer?.invalidate()
        let trimmed = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            searchResults = []
            isLoading = false
            return
        }
        debounceTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { _ in
            self.searchByQuery()
        }
    }
    
    private func searchByBarcode(barcode: String) {
        isLoading = true
        foodAPIService.fetchFoodByBarcode(barcode: barcode) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let foodItem):
                    if self.searchContext == "recipe" {
                        self.onFoodItemLogged(foodItem)
                        self.dismiss()
                    } else {
                        self.selectedFoodItemForDetail = foodItem
                    }
                case .failure(let error):
                    self.errorState = (true, "Could not find a food for barcode \(barcode). Error: \(error.localizedDescription)")
                    self.searchResults = []
                }
            }
        }
    }
    
    private func searchByQuery() {
        guard !searchQuery.isEmpty else { return }
        isLoading = true
        foodAPIService.fetchFoodByQuery(query: searchQuery) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let foodItems):
                    self.searchResults = foodItems
                case .failure(let error):
                    self.errorState = (true, "Food search failed. Please try again. Error: \(error.localizedDescription)")
                    self.searchResults = []
                }
            }
        }
    }
    
    private func fetchRecentFoods() {
        guard let userID = Auth.auth().currentUser?.uid else { return }
        isLoading = true
        dailyLogService.fetchRecentFoodItems(for: userID) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let items):
                    self.recentFoodItems = items
                case .failure(_):
                    self.recentFoodItems = []
                }
            }
        }
    }
    
    private func fetchMyFoods() {
        guard let userID = Auth.auth().currentUser?.uid else { return }
        isLoading = true
        dailyLogService.fetchMyFoodItems(for: userID) { result in
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let items):
                    self.myFoodItems = items
                case .failure(_):
                    self.myFoodItems = []
                }
            }
        }
    }
}
