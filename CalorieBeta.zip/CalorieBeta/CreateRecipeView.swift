import SwiftUI

struct CreateRecipeView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var recipeService: RecipeService
    @State private var recipe: UserRecipe

    @State private var newInstruction: String = ""
    @State private var showingIngredientSheet = false
    @State private var showingFoodSearch = false
    @State private var ingredientToEditId: RecipeIngredient.ID?

    private var isEditMode: Bool

    init(recipeService: RecipeService, recipeToEdit: UserRecipe? = nil) {
        self.recipeService = recipeService
        if let existingRecipe = recipeToEdit {
            _recipe = State(initialValue: existingRecipe)
            self.isEditMode = true
        } else {
            _recipe = State(initialValue: UserRecipe(userID: "", name: ""))
            self.isEditMode = false
        }
    }

    private func findIngredientBinding(for id: RecipeIngredient.ID?) -> Binding<RecipeIngredient>? {
        guard let id = id, let index = recipe.ingredients.firstIndex(where: { $0.id == id }) else {
            return nil
        }
        return $recipe.ingredients[index]
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Recipe Details")) {
                    TextField("Recipe Name", text: $recipe.name)
                    
                    Stepper(value: $recipe.totalServings, in: 1...100, step: 1.0) {
                        Text("Servings: \(recipe.totalServings, specifier: "%.1f")")
                    }
                }

                Section(header: Text("Ingredients")) {
                    Button("Add Ingredient from Search") {
                        showingFoodSearch = true
                    }
                    
                    if !recipe.ingredients.isEmpty {
                        ForEach(recipe.ingredients.indices, id: \.self) { index in
                            IngredientRowView(ingredient: $recipe.ingredients[index], onMatchFound: { foodItem in
                                updateIngredient(originalId: recipe.ingredients[index].id, with: foodItem)
                            })
                            .onTapGesture {
                                self.ingredientToEditId = recipe.ingredients[index].id
                                self.showingIngredientSheet = true
                            }
                        }
                        .onDelete(perform: deleteIngredient)
                    }
                }
                
                Section(header: Text("Instructions")) {
                    ForEach(Array(recipe.instructions?.enumerated() ?? [].enumerated()), id: \.offset) { index, instruction in
                        HStack {
                            Text("\(index + 1).")
                                .bold()
                            Text(instruction)
                        }
                    }
                    .onDelete(perform: deleteInstruction)
                    
                    HStack {
                        TextField("Add new step", text: $newInstruction, onCommit: addInstruction)
                        Button(action: addInstruction) {
                            Image(systemName: "plus.circle.fill")
                        }
                        .disabled(newInstruction.isEmpty)
                    }
                }
                
                Section(header: Text("Nutrition Per Serving")) {
                     if recipe.ingredients.isEmpty {
                        Text("Add ingredients to see nutrition info.")
                            .appFont(size: 14)
                            .foregroundColor(.secondary)
                    } else {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Calories: \(recipe.nutritionPerServing.calories, specifier: "%.0f") kcal")
                            Text("Protein: \(recipe.nutritionPerServing.protein, specifier: "%.1f") g")
                            Text("Carbs: \(recipe.nutritionPerServing.carbs, specifier: "%.1f") g")
                            Text("Fats: \(recipe.nutritionPerServing.fats, specifier: "%.1f") g")
                        }
                        .appFont(size: 15)
                    }
                }
            }
            .navigationTitle(isEditMode ? "Edit Recipe" : "Create Recipe")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        recipeService.saveRecipe(recipe) { result in
                            if case .success = result {
                                dismiss()
                            }
                        }
                    }
                    .disabled(recipe.name.isEmpty || recipe.ingredients.isEmpty)
                }
            }
            .sheet(isPresented: $showingFoodSearch) {
                FoodSearchView(
                    dailyLog: .constant(nil),
                    onFoodItemLogged: { foodItem in
                        addIngredientFromSearch(foodItem)
                    },
                    searchContext: "recipe"
                )
            }
            .sheet(isPresented: $showingIngredientSheet) {
                if let ingredientBinding = findIngredientBinding(for: ingredientToEditId) {
                    FoodDetailView(
                        initialFoodItem: foodItem(from: ingredientBinding.wrappedValue),
                        dailyLog: .constant(nil),
                        source: "recipe_ingredient_edit",
                        onLogUpdated: {},
                        onUpdate: { updatedFoodItem in
                            updateIngredient(from: updatedFoodItem, for: ingredientBinding)
                            ingredientToEditId = nil
                        }
                    )
                }
            }
        }
    }

    private func addIngredientFromSearch(_ foodItem: FoodItem) {
        let newIngredient = RecipeIngredient(
            foodId: foodItem.id,
            foodName: foodItem.name,
            quantity: 1,
            selectedServingDescription: foodItem.servingSize,
            selectedServingWeightGrams: foodItem.servingWeight,
            calories: foodItem.calories,
            protein: foodItem.protein,
            carbs: foodItem.carbs,
            fats: foodItem.fats,
            saturatedFat: foodItem.saturatedFat,
            polyunsaturatedFat: foodItem.polyunsaturatedFat,
            monounsaturatedFat: foodItem.monounsaturatedFat,
            fiber: foodItem.fiber,
            calcium: foodItem.calcium,
            iron: foodItem.iron,
            potassium: foodItem.potassium,
            sodium: foodItem.sodium,
            vitaminA: foodItem.vitaminA,
            vitaminC: foodItem.vitaminC,
            vitaminD: foodItem.vitaminD,
            vitaminB12: foodItem.vitaminB12,
            folate: foodItem.folate
        )
        recipe.ingredients.append(newIngredient)
        recipe.calculateTotals()
    }

    private func deleteIngredient(at offsets: IndexSet) {
        recipe.ingredients.remove(atOffsets: offsets)
        recipe.calculateTotals()
    }
    
    private func addInstruction() {
        guard !newInstruction.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        if recipe.instructions == nil {
            recipe.instructions = []
        }
        recipe.instructions?.append(newInstruction)
        newInstruction = ""
    }

    private func deleteInstruction(at offsets: IndexSet) {
        recipe.instructions?.remove(atOffsets: offsets)
    }

    private func foodItem(from ingredient: RecipeIngredient) -> FoodItem {
        let singleServingCalories = ingredient.quantity > 0 ? ingredient.calories / ingredient.quantity : 0
        let singleServingProtein = ingredient.quantity > 0 ? ingredient.protein / ingredient.quantity : 0
        let singleServingCarbs = ingredient.quantity > 0 ? ingredient.carbs / ingredient.quantity : 0
        let singleServingFats = ingredient.quantity > 0 ? ingredient.fats / ingredient.quantity : 0
        
        let servingSizeWithQuantity = "\(ingredient.quantity) x \(ingredient.selectedServingDescription ?? "1 serving")"
    
        return FoodItem(
            id: ingredient.foodId ?? UUID().uuidString,
            name: ingredient.foodName,
            calories: singleServingCalories,
            protein: singleServingProtein,
            carbs: singleServingCarbs,
            fats: singleServingFats,
            servingSize: servingSizeWithQuantity,
            servingWeight: ingredient.selectedServingWeightGrams ?? 0
        )
    }
    
    private func updateIngredient(from foodItem: FoodItem, for binding: Binding<RecipeIngredient>) {
        let parsedServing = parseQuantityFromServing(foodItem.servingSize)
        
        var updatedIngredient = binding.wrappedValue
        updatedIngredient.quantity = parsedServing.qty
        updatedIngredient.selectedServingDescription = parsedServing.baseDesc
        
        updatedIngredient.calories = foodItem.calories
        updatedIngredient.protein = foodItem.protein
        updatedIngredient.carbs = foodItem.carbs
        updatedIngredient.fats = foodItem.fats
        updatedIngredient.saturatedFat = foodItem.saturatedFat
        updatedIngredient.polyunsaturatedFat = foodItem.polyunsaturatedFat
        updatedIngredient.monounsaturatedFat = foodItem.monounsaturatedFat
        updatedIngredient.fiber = foodItem.fiber
        updatedIngredient.calcium = foodItem.calcium
        updatedIngredient.iron = foodItem.iron
        updatedIngredient.potassium = foodItem.potassium
        updatedIngredient.sodium = foodItem.sodium
        updatedIngredient.vitaminA = foodItem.vitaminA
        updatedIngredient.vitaminC = foodItem.vitaminC
        updatedIngredient.vitaminD = foodItem.vitaminD
        updatedIngredient.vitaminB12 = foodItem.vitaminB12
        updatedIngredient.folate = foodItem.folate
    
        binding.wrappedValue = updatedIngredient
        recipe.calculateTotals()
    }
    
    private func updateIngredient(originalId: String, with foodItem: FoodItem) {
        if let index = recipe.ingredients.firstIndex(where: { $0.id == originalId }) {
            recipe.ingredients[index].foodId = foodItem.id
            recipe.ingredients[index].calories = foodItem.calories
            recipe.ingredients[index].protein = foodItem.protein
            recipe.ingredients[index].carbs = foodItem.carbs
            recipe.ingredients[index].fats = foodItem.fats
            recipe.ingredients[index].saturatedFat = foodItem.saturatedFat
            recipe.ingredients[index].polyunsaturatedFat = foodItem.polyunsaturatedFat
            recipe.ingredients[index].monounsaturatedFat = foodItem.monounsaturatedFat
            recipe.ingredients[index].fiber = foodItem.fiber
            recipe.ingredients[index].calcium = foodItem.calcium
            recipe.ingredients[index].iron = foodItem.iron
            recipe.ingredients[index].potassium = foodItem.potassium
            recipe.ingredients[index].sodium = foodItem.sodium
            recipe.ingredients[index].vitaminA = foodItem.vitaminA
            recipe.ingredients[index].vitaminC = foodItem.vitaminC
            recipe.ingredients[index].vitaminD = foodItem.vitaminD
            recipe.ingredients[index].vitaminB12 = foodItem.vitaminB12
            recipe.ingredients[index].folate = foodItem.folate
            recipe.calculateTotals()
        }
    }

    private func parseQuantityFromServing(_ servingDesc: String) -> (qty: Double, baseDesc: String) {
        let components = servingDesc.components(separatedBy: " x ")
        if components.count == 2, let qty = Double(components[0]), qty > 0 {
            return (qty, components[1])
        }
        return (1.0, servingDesc)
    }
}
